#include <iostream>

using namespace std;

int main()
{
    int n,oglindit,copia_lui_n;
    cout<<"Introduceti numarul n: ";
    cin>>n;
    copia_lui_n=n;
    while(n!=0)
    {
        oglindit=oglindit*10+n%10;
        n=n/10;
    }
    if(copia_lui_n==oglindit)
        cout<<"Numarul este palindrom";
    else
        cout<<"Numarul nu este palindrom";
    return 0;
}
