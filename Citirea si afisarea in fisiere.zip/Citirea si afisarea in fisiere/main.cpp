#include <iostream>
#include<fstream>
using namespace std;

int main()
{
    ifstream f("azi.in");
    ofstream g("maine.out");
    int n,x;
    f>>n;
    for(int i=1;i<=n;i++)
    {
        f>>x;
        g<<x<<endl;
    }
    return 0;
}
