#include <iostream>
#include <string>
using namespace std;
struct Carte
{
    string titlu;
    string autor;
    string editura;
    int an_publicatie;
    int numarul_pagini;
    float pret;
};
void afisare_carte_autor(Carte carti[], int n, string autor)
{
    cout<<"Cartile scrise de autorul: "<<autor<<" "<<"sunt: "<< endl;
    for (int i = 0; i < n; i++)
    {
        if (carti[i].autor == autor)
        {
            cout << carti[i].titlu << endl;
        }
    }
}
void sortarea_cartilor(Carte carti[], int n, bool crescator)
{
    for (int i = 0; i < n-1; i++)
    {
        for (int j = i+1; j < n; j++)

        {
            if ((crescator && carti[i].pret > carti[j].pret) || (!crescator && carti[i].pret < carti[j].pret))
            {
                Carte aux = carti[i];
                carti[i] = carti[j];
                carti[j] = aux;
            }
        }
    }
     cout << "Cartile sortate dupa pret sunt:" << endl;
    for (int i = 0; i < n; i++)
    {
        cout << "Titlu: " << carti[i].titlu << endl;
        cout << "Autor: " << carti[i].autor << endl;
        cout << "Editura: " << carti[i].editura << endl;
        cout << "Anul publicarii: " << carti[i].an_publicatie << endl;
        cout << "Numarul de pagini: " << carti[i].numarul_pagini << endl;
        cout << "Pretul: " << carti[i].pret << endl;
        cout << endl;
    }
}
void modificarea_pretului(Carte carti[], int n, string titlu, float pret_nou)
{
    for (int i = 0; i < n; i++)
    {
        if (carti[i].titlu == titlu)
        {
            carti[i].pret = pret_nou;
            cout << "Pretul cartii "<< titlu<< " a fost modificat." << endl;
            return;
        }
    }
    cout<<"Cartea "<<titlu <<"nu a fost gasita in lista." << endl;
}

int main()
{
    int MAX_CARTI = 100;
    Carte carti[MAX_CARTI];
    int n;
    cout << "Introduceti numarul de carti: ";
    cin >> n;
    cin.get();
    for (int i = 0; i < n; i++)
    {
        cout << "Introduceti detaliile pentru carte:" << i+1 << ":" << endl;
        cout << "Titlu: ";
        getline(cin, carti[i].titlu);
        cout << "Autor: ";
        getline(cin, carti[i].autor);
        cout << "Editura: ";
        getline(cin, carti[i].editura);
        cout << "Anul publicarii: ";
        cin >> carti[i].an_publicatie;
        cout << "Numarul de pagini: ";
        cin >> carti[i].numarul_pagini;
        cout << "Pretul: ";
        cin >> carti[i].pret;
        cin.get();
        cout << endl;
    }
    afisare_carte_autor(carti, n, "Mihai Eminescu");
    cout << "Alege modul de sortare dupa pret (crescator): ";
    int optiune;
    cin >> optiune;
    if (optiune == 1)
    {
        sortarea_cartilor(carti, n, true);
    }
    else
    if (optiune == 2)
    {
        sortarea_cartilor(carti, n, false);
    }
    else
    {
        cout << "Optiune invalida." << endl;
    }
    modificarea_pretului(carti, n, "Ion", 100.0);
    return 0;
}
