#include <iostream>
using namespace std;

int v[100];
int n = 0;

void AdaugaFinal(int x)
{
    v[n++] = x;
}

void InserareInceput(int x)
{
    for (int i = n - 1; i >= 0; i--)
    {
        v[i + 1] = v[i];
    }
    v[0] = x;
    n++;
}

void Afisare()
{
    for (int i = 0; i < n; i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
}

void StergereElement(int x)
{
    for (int i = 0; i < n; i++)
    {
        if (v[i] == x)
        {
            for (int j = i; j < n - 1; j++)
            {
                v[j] = v[j + 1];
            }
            n--;
            break;
        }
    }
}

void InserarePozitie(int x, int pozitie)
{
    for (int i = n - 1; i >= pozitie; i--)
    {
        v[i + 1] = v[i];
    }
    v[pozitie] = x;
    n++;
}

void ordonare()
{
    int ord, aux;
    do
    {
        ord = 1;
        for (int i = 0; i < n - 1; i++)
        {
            if (v[i] > v[i + 1])
            {
                aux = v[i];
                v[i] = v[i + 1];
                v[i + 1] = aux;
                ord = 0;
            }
        }
    } while (ord == 0);
}

int main()
{
    AdaugaFinal(3);
    AdaugaFinal(5);
    AdaugaFinal(7);
    ordonare();
    cout << "Vectorul initial: ";
    Afisare();
    InserarePozitie(12, 1);
    cout << "Vectorul dupa inserarea la pozitia 1: ";
    Afisare();
    return 0;
}

